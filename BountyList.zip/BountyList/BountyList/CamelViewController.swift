

import UIKit

class CamelViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    let nameList = ["camel1", "camel2", "camel3"]
    let bountyList = ["낙타송! 다 같이 불러봐요", "낙타를 외계인으로부터 구출해요!", "낙타! 넌 누구니?"]
    
//   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//       // DetailViewController 데이터 줄꺼에요
//       if segue.identifier == "showDetail" {
//           let vc = segue.destination as? DetailViewController
//           if let index = sender as? Int {
//               vc?.name = nameList[index]
//               vc?.name = bountyList[index]
//
//           }
//       }
//   }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    // UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bountyList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ListCell else {
            return UITableViewCell()
        }
        
        let img = UIImage(named: "\(nameList[indexPath.row]).jpg")
        cell.imgView.image = img
        cell.nameLabel.text = nameList[indexPath.row]
        cell.bountyLabel.text = "\(bountyList[indexPath.row])"
        return cell
        
    }
    
    // UITableViewDelegate
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print("--> \(indexPath.row)")
//        performSegue(withIdentifier: "showDetail", sender: indexPath.row)
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

               tableView.deselectRow(at: indexPath, animated: true)
               switch indexPath.row {
               case 0: UIApplication.shared.open(URL(string : "https://www.youtube.com/watch?v=TSG03HNG0_U")! as URL, options: [:], completionHandler: nil)

               case 1: UIApplication.shared.open(URL(string : "https://www.youtube.com/watch?v=tJ0ZNNoS4kQ")! as URL, options: [:], completionHandler: nil)

               case 2: UIApplication.shared.open(URL(string : "https://www.youtube.com/watch?v=fN0ZC2pofds")! as URL, options: [:], completionHandler: nil)
               default:

                   return

               }

           }

}
  



