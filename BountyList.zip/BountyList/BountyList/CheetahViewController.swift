

import UIKit

class CheetahViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    let nameList = ["cheetah1", "cheetah2", "cheetah3"]
    let bountyList = ["치타송! 다 같이 불러봐요", "귀여운 아기치타와 같이 놀까요?", "치타와 함께 춤을 춰봐요"]
    
//   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//       // DetailViewController 데이터 줄꺼에요
//       if segue.identifier == "showDetail" {
//           let vc = segue.destination as? DetailViewController
//           if let index = sender as? Int {
//               vc?.name = nameList[index]
//               vc?.name = bountyList[index]
//
//           }
//       }
//   }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    // UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bountyList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ListCell else {
            return UITableViewCell()
        }
        
        let img = UIImage(named: "\(nameList[indexPath.row]).jpg")
        cell.imgView.image = img
        cell.nameLabel.text = nameList[indexPath.row]
        cell.bountyLabel.text = "\(bountyList[indexPath.row])"
        return cell
        
    }
    
    // UITableViewDelegate
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print("--> \(indexPath.row)")
//        performSegue(withIdentifier: "showDetail", sender: indexPath.row)
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

               tableView.deselectRow(at: indexPath, animated: true)
               switch indexPath.row {
               case 0: UIApplication.shared.open(URL(string : "https://www.youtube.com/watch?v=busUE3S_gjY")! as URL, options: [:], completionHandler: nil)

               case 1: UIApplication.shared.open(URL(string : "https://www.youtube.com/watch?v=UdILcn_Cpw0")! as URL, options: [:], completionHandler: nil)

               case 2: UIApplication.shared.open(URL(string : "https://www.youtube.com/watch?v=qJfiEQrg35A")! as URL, options: [:], completionHandler: nil)
               default:

                   return

               }

           }

}
  



