

import UIKit

class OXViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    let nameList = ["ox1", "ox2", "ox3"]
    let bountyList = ["송아지 율동! 같이 춰요~", "꾸러기 동요 송아지 송~", "송아지의 겨울 나들이!"]
    
//   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//       // DetailViewController 데이터 줄꺼에요
//       if segue.identifier == "showDetail" {
//           let vc = segue.destination as? DetailViewController
//           if let index = sender as? Int {
//               vc?.name = nameList[index]
//               vc?.name = bountyList[index]
//
//           }
//       }
//   }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    // UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bountyList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ListCell else {
            return UITableViewCell()
        }
        
        let img = UIImage(named: "\(nameList[indexPath.row]).jpg")
        cell.imgView.image = img
        cell.nameLabel.text = nameList[indexPath.row]
        cell.bountyLabel.text = "\(bountyList[indexPath.row])"
        return cell
        
    }
    
    // UITableViewDelegate
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print("--> \(indexPath.row)")
//        performSegue(withIdentifier: "showDetail", sender: indexPath.row)
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

               tableView.deselectRow(at: indexPath, animated: true)
               switch indexPath.row {
               case 0: UIApplication.shared.open(URL(string : "https://www.youtube.com/watch?v=HIb0wGEy1lU")! as URL, options: [:], completionHandler: nil)

               case 1: UIApplication.shared.open(URL(string : "https://www.youtube.com/watch?v=1nYGU_8vHxQ")! as URL, options: [:], completionHandler: nil)

               case 2: UIApplication.shared.open(URL(string : "https://www.youtube.com/watch?v=oVf_8rq8TdY")! as URL, options: [:], completionHandler: nil)
               default:

                   return

               }

           }

}
  



